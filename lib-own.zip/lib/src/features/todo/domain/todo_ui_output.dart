import 'package:clean_framework/clean_framework.dart';

import '../model/todo_model.dart';
import 'todo_entity.dart';

class TodoUIOutput extends Output {
  const TodoUIOutput({
    required this.todoList,
    required this.status,
    required this.isRefresh,
    required this.formController,
  });

  final List<TodoModel> todoList;
  final TodoStatus status;

  final bool isRefresh;

  final FormController formController;

  @override
  List<Object?> get props => [todoList, status, isRefresh];
}
