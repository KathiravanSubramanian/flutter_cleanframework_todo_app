import 'dart:math';

import 'package:clean_framework/clean_framework.dart';
import '../model/todo_model.dart';
import 'todo_entity.dart';
import 'todo_ui_output.dart';

class TodoUseCase extends UseCase<TodoEntity> {
  TodoUseCase()
      : super(
          entity: TodoEntity(
            formController: FormController(
              validators: {const InputFieldValidator.required()},
            ),
          ),
          transformers: [
            TodoUIOutputTransformer(),
          ],
        ) {
    _titleController =
        TextFieldController.create(entity.formController, tag: TodoTags.title);
    _descriptionController = TextFieldController.create(entity.formController,
        tag: TodoTags.description);
  }

  late final TextFieldController _titleController;
  late final TextFieldController _descriptionController;

  // random 5 digit number generator 0-99999
  String get randomId => (0 + (99999 - 0) * Random().nextDouble()).toString();

  // created date method
  String get createdDate => DateTime.now().toIso8601String();
  // updated date method
  String get updatedDate => DateTime.now().toIso8601String();

  // fetchData
  Future<void> fetchData({bool isRefresh = false}) async {
    if (!isRefresh) {
      entity = entity.copyWith(status: TodoStatus.loading);
    }
    List<TodoModel> temp = [];
    for (var i = 0; i < 5; i++) {
      temp.add(
        TodoModel(
          id: '$i',
          title: 'title $i',
          description: 'description $i',
          isCompleted: false,
          createdAt: createdDate,
          updatedAt: updatedDate,
        ),
      );
    }

    entity = entity.copyWith(
      todoList: temp.toList(growable: false),
      status: TodoStatus.loaded,
      isRefresh: false,
    );

    if (isRefresh) {
      entity = entity.copyWith(isRefresh: false, status: TodoStatus.loaded);
    }
  }

  // createTodo
  Future<void> createTodo() async {
    final formController = entity.formController;
    if (formController.validate()) {
      final temp = entity.todoList.toList(growable: true);
      temp.add(TodoModel(
          id: randomId,
          title: _titleController.value ?? '',
          description: _descriptionController.value ?? '',
          isCompleted: false,
          createdAt: createdDate,
          updatedAt: updatedDate));

      formController.setSubmitted(false);
      formController.reset();
      entity = entity.copyWith(
        todoList: temp.toList(growable: false),
        status: TodoStatus.loaded,
      );
    }
  }

  // fetchById
  Future<void> fetchById(String id) async {
    final todo = entity.todoList.firstWhere((element) => element.id == id);
    _titleController.setValue(todo.title);
    _descriptionController.setValue(todo.description);
  }

  // updateById
  Future<void> updateById(String id) async {
    entity = entity.copyWith(
      todoList: entity.todoList.map((e) {
        if (e.id == id) {
          return TodoModel(
            id: e.id,
            title: _titleController.value ?? '',
            description: _descriptionController.value ?? '',
            isCompleted: e.isCompleted,
            createdAt: e.createdAt,
            updatedAt: updatedDate,
          );
        }
        return e;
      }).toList(),
      status: TodoStatus.loaded,
      isRefresh: false,
    );
  }

  // deleteById
  Future<void> deleteById(String id) async {
    entity = entity.copyWith(
      todoList: entity.todoList.where((element) => element.id != id).toList(),
      status: TodoStatus.loaded,
      isRefresh: false,
    );
  }

  @override
  void dispose() {
    entity.formController.dispose();
    super.dispose();
  }
}

class TodoUIOutputTransformer
    extends OutputTransformer<TodoEntity, TodoUIOutput> {
  @override
  TodoUIOutput transform(TodoEntity entity) {
    return TodoUIOutput(
      todoList: entity.todoList.toList(),
      status: entity.status,
      isRefresh: entity.isRefresh,
      formController: entity.formController,
    );
  }
}
