import 'package:clean_framework/clean_framework.dart';

import '../model/todo_model.dart';

enum TodoTags { title, description, completed }

enum TodoStatus { initial, loading, loaded, failed }

class TodoEntity extends Entity {
  const TodoEntity({
    this.todoList = const [],
    this.status = TodoStatus.initial,
    this.isRefresh = false,
    required this.formController,
  });

  final List<TodoModel> todoList;
  final TodoStatus status;

  final bool isRefresh;
  final FormController formController;

  @override
  List<Object?> get props {
    return [todoList, status, isRefresh, formController];
  }

  @override
  TodoEntity copyWith({
    List<TodoModel>? todoList,
    TodoStatus? status,
    bool? isRefresh,
    String? title,
    String? description,
    bool? isCompleted,
  }) {
    return TodoEntity(
      todoList: todoList ?? this.todoList,
      status: status ?? this.status,
      isRefresh: isRefresh ?? this.isRefresh,
      formController: formController,
    );
  }
}
