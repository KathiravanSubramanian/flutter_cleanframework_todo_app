import 'package:clean_framework/clean_framework.dart';
import '../domain/todo_use_case.dart';

final todoUseCaseProvider = UseCaseProvider(TodoUseCase.new);
