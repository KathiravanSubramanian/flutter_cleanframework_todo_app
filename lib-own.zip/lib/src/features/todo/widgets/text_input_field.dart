import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';

class TextInputField extends StatelessWidget {
  const TextInputField({
    required this.tag,
    required this.hintText,
    this.obscureText = false,
    super.key,
  });

  final Object tag;
  final String hintText;
  final bool obscureText;

  @override
  Widget build(BuildContext context) {
    final themeCxt = Theme.of(context);

    return TextInputFieldBuilder(
      tag: tag,
      builder: (context, controller, textEditingController) {
        return TextFormField(
          style: themeCxt.textTheme.labelMedium,
          controller: textEditingController,
          decoration: InputDecoration(
            hintText: hintText,
            errorText: controller.error.message,
          ),
          onChanged: controller.onChanged,
          obscureText: obscureText,
          enabled: !controller.isSubmitted,
        );
      },
    );
  }
}
