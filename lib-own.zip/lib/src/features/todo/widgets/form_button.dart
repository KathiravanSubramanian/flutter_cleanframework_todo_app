import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';

class FormButton extends StatelessWidget {
  const FormButton({required this.onPressed, required this.child, super.key});

  final VoidCallback onPressed;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final themeCxt = Theme.of(context);

    return UniformBuilder(
      builder: (context, controller, _) {
        return ElevatedButton(
          style: themeCxt.elevatedButtonTheme.style,
          onPressed: onPressed,
          child: controller.isSubmitted ? const Text('Submitting...') : child,
        );
      },
    );
  }
}
