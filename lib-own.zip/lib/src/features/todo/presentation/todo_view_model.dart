import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/foundation.dart';

import '../model/todo_model.dart';

class TodoViewModel extends ViewModel {
  final FormController formController;

  final List<TodoModel> todoList;
  final bool isLoading;
  final bool hasFailedLoading;

  final VoidCallback onRetry;
  final AsyncCallback onRefresh;

  final VoidCallback createTodo;
  final ValueChanged<String> fetchById;
  final ValueChanged<String> updateById;
  final ValueChanged<String> deleteById;

  const TodoViewModel({
    required this.formController,
    required this.todoList,
    required this.isLoading,
    required this.hasFailedLoading,
    required this.onRetry,
    required this.onRefresh,
    required this.createTodo,
    required this.fetchById,
    required this.updateById,
    required this.deleteById,
  });

  @override
  List<Object?> get props => [
        todoList,
        isLoading,
        hasFailedLoading,
      ];
}
