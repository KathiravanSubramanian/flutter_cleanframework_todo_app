import 'dart:developer';

import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';
import '../domain/todo_entity.dart';
import '../domain/todo_ui_output.dart';
import '../domain/todo_use_case.dart';
import '../providers/todo_providers.dart';
import 'todo_view_model.dart';

class TodoPresenter
    extends Presenter<TodoViewModel, TodoUIOutput, TodoUseCase> {
  TodoPresenter({
    super.key,
    required super.builder,
  }) : super(provider: todoUseCaseProvider);

  @override
  TodoViewModel createViewModel(TodoUseCase useCase, TodoUIOutput output) {
    return TodoViewModel(
      todoList: output.todoList.toList(growable: false),
      onRefresh: () => useCase.fetchData(isRefresh: true),
      onRetry: () => useCase.fetchData(),
      isLoading: output.status == TodoStatus.loading,
      hasFailedLoading: output.status == TodoStatus.failed,
      formController: output.formController,
      createTodo: () => useCase.createTodo(),
      fetchById: (id) => useCase.fetchById(id),
      updateById: (id) => useCase.updateById(id),
      deleteById: (id) => useCase.deleteById(id),
    );
  }

  @override
  void onLayoutReady(BuildContext context, TodoUseCase useCase) async {
    super.onLayoutReady(context, useCase);
    useCase.fetchData();
  }

  @override
  void onOutputUpdate(BuildContext context, TodoUIOutput output) async {
    log('onOutputUpdate');
    log('${output.status}');
    if (output.isRefresh) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            output.status == TodoStatus.failed
                ? 'Sorry, failed refreshing!'
                : 'Refreshed successfully!',
          ),
        ),
      );
    }
  }
}
