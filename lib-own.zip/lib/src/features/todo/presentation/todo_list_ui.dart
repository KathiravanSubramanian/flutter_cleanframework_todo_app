import 'package:clean_framework/clean_framework.dart';
import 'package:clean_framework_router/clean_framework_router.dart';
import 'package:flutter/material.dart';
import '../../../routes/routes.dart';
import '../widgets/todo_card.dart';
import 'todo_presenter.dart';
import 'todo_view_model.dart';

class TodoListUI extends UI<TodoViewModel> {
  TodoListUI({super.key});

  @override
  TodoPresenter create(WidgetBuilder builder) {
    return TodoPresenter(builder: builder);
  }

  @override
  Widget build(BuildContext context, TodoViewModel viewModel) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Todo List'),
        centerTitle: false,
        titleTextStyle: textTheme.displaySmall!.copyWith(
          fontWeight: FontWeight.w300,
        ),
      ),
      body: Stack(
        children: [
          todoList(viewModel),
          if (viewModel.isLoading)
            Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: Colors.white.withOpacity(0.5),
                child: const Center(child: CircularProgressIndicator()))
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.router.push(Routes.todoForm, params: {'id': '-1'});
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget noDataFound(TodoViewModel viewModel) {
    if (!viewModel.isLoading) {
      return const Center(
        child: Text('No data found',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      );
    } else {
      return const SizedBox();
    }
  }

  SafeArea todoList(TodoViewModel viewModel) {
    return SafeArea(
      child: Visibility(
        visible: viewModel.todoList.isNotEmpty,
        replacement: noDataFound(viewModel),
        child: RefreshIndicator(
          onRefresh: () async {
            await viewModel.onRefresh();
          },
          child: ListView.builder(
            itemCount: viewModel.todoList.length,
            itemBuilder: (context, index) {
              final todo = viewModel.todoList[index];
              return TodoCard(index: index, todo: todo, viewModel: viewModel);
            },
          ),
        ),
      ),
    );
  }
}
