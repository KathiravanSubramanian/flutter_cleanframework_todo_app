import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';

import '../domain/todo_entity.dart';
import '../widgets/form_button.dart';
import '../widgets/text_input_field.dart';
import 'todo_presenter.dart';
import 'todo_view_model.dart';

class TodoFormUI extends UI<TodoViewModel> {
  final String id;
  TodoFormUI({
    super.key,
    required this.id,
  });

  @override
  TodoPresenter create(WidgetBuilder builder) {
    return TodoPresenter(builder: builder);
  }

  @override
  Widget build(BuildContext context, viewModel) {
    if (id != '-1') {
      viewModel.fetchById(id);
    }
    return Stack(
      children: [
        InputFormWidget(id: id, viewModel: viewModel),
        if (viewModel.isLoading)
          Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              color: Colors.white.withOpacity(0.5),
              child: const Center(child: CircularProgressIndicator()))
      ],
    );
  }
}

class InputFormWidget extends StatelessWidget {
  const InputFormWidget({
    super.key,
    required this.id,
    required this.viewModel,
  });

  final String id;
  final TodoViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(id != '-1' ? 'Edit' : 'Add'),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        child: InputForm(
            controller: viewModel.formController,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  const TextInputField(
                    tag: TodoTags.title,
                    hintText: 'Title',
                  ),
                  const SizedBox(height: 20),
                  const TextInputField(
                    tag: TodoTags.description,
                    hintText: 'Description',
                  ),
                  const SizedBox(height: 20),
                  FormButton(
                    onPressed: () {
                      if (id != '-1') {
                        viewModel.updateById(id);
                      } else {
                        viewModel.createTodo();
                      }
                    },
                    child: Text(id != '-1' ? 'Update' : 'Add'),
                  ),
                ],
              ),
            )),
      ),
    );
  }
}
