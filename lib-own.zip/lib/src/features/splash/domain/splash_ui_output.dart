import 'package:clean_framework/clean_framework.dart';

class SplashUIOutput extends Output {
  @override
  List<Object?> get props => [];
}
