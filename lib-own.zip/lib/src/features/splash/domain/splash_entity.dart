import 'package:clean_framework/clean_framework.dart';

class SplashEntity extends Entity {
  @override
  List<Object?> get props => [];
}
