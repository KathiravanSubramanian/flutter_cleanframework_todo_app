import 'package:clean_framework/clean_framework.dart';
import '../domain/splash_use_case.dart';

final splashUseCaseProvider = UseCaseProvider(SplashUseCase.new);
