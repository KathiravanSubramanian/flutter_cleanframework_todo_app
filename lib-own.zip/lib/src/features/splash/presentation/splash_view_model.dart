import 'package:clean_framework/clean_framework.dart';

class SplashViewModel extends ViewModel {
  @override
  List<Object?> get props => [];
}
