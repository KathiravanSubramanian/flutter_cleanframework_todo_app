class AppStrings {
  static const String appName = 'Todo App';
}
