// create a class app color to store light and dark theme color
class AppBrandedColor {
  // light theme color

  // dark theme color
}
